package org.jdbc.loginApp;
import java.sql.*;
import java.util.*;
public class LoginVAlidation {
	public static void main(String[] args) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String qry = ("select username from seja4.login where name=? and password=?");
        
        Scanner sc =new Scanner (System.in);
        System.out.println("Enter Name");
        String name = sc.next();
        System.out.println("Enter Password");
        String pwd = sc.next();
        sc.close();
        
       
       	 try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("Driver Class Loaded And Registered");
				
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
				System.out.println("Connection establish with DBServer");
				
				pstmt = con.prepareStatement(qry);
				
				pstmt.setString(1, name);
				pstmt.setString(2, pwd);
				rs = pstmt.executeQuery();
				
				if(rs.next())
				{
					String Uname = rs.getString(1);
					System.out.println("welcome "+Uname);
					
				}
				else
				{
					System.out.println("Invalid name/password");
				}
			} catch (ClassNotFoundException | SQLException e) {
				
				e.printStackTrace();
			}

       	 finally
       	 {
       		 if(rs != null)
       		 {
       			 try {
						rs.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
       		 }
       		 
       		 if(pstmt != null)
       		 {
       			 try {
						pstmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
       		 }
       		 
       		 if(con != null)
       		 {
       			 try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
       		 }
       		 
       		System.out.println("All Costly Connection Closed");
       	 }

	}

}
