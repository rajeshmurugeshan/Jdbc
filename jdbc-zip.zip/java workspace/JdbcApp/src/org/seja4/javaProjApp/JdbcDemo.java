package org.seja4.javaProjApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcDemo {
 public static void main(String[] args)
 {
	Connection con=null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver class loaded and registered");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
		System.out.println("established connection sucessfully");
	} catch (ClassNotFoundException | SQLException e) {
		e.printStackTrace();
	}
	finally {
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		System.out.println("closed costly resources sucessfully");
	}
}
}
