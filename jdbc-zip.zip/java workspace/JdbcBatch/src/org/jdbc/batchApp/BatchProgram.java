package org.jdbc.batchApp;
import java.sql.*;
public class BatchProgram {
public static void main(String[] args) {
		
		Connection con = null;
		Statement stmt = null;
		
		String insqry = "insert into seja4.student value(4,'prasd',85.55)";
		String upqry = "update seja4.login set name = 'raj' and password = 'xyz'";
		String delqry = "delete from seja4.student where id=2";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Class Loaded And registered");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
			System.out.println("Connectioin Establish with DBServer");
			
			stmt = con.createStatement();
			//ADD DML QUERIES INTO BATCH //
			
			stmt.addBatch(insqry);
			stmt.addBatch(upqry);
			stmt.addBatch(delqry);
			
			int arr[] = stmt.executeBatch();
			for(int i : arr)
			{
				System.out.println(i);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if(con != null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			System.out.println("All Costly Connection Closed ");
		}
	}
}
