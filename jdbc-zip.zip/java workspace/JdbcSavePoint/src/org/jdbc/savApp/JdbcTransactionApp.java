package org.jdbc.savApp;

import java.sql.*;
import java.util.*;
public class JdbcTransactionApp 
{
	public static void main(String[] args)
	{
		Connection con=null;
		PreparedStatement pstmt=null;
		PreparedStatement pstmt1=null;
		Savepoint sp=null;
		
		
		String stded="insert into seja4.student values(?,?,?,?)";
		String stdpr="insert into seja4.student values(?,?,?)";
		Scanner sc=new Scanner (System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter dept");
		String dept=sc.next();
		System.out.println("enter perc");
		double perc=sc.nextDouble();
		System.out.println("enter place");
		String place=sc.next();
		sc.close();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver class loaded and registered");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
			System.out.println("established connection sucessfully");
			// Disable autocommit mode//
			con.setAutoCommit(false);
			pstmt=con.prepareStatement(stded);
			//set value for place holder//
			pstmt.setInt(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, dept);
			pstmt.setDouble(4, perc);
			System.out.println("Student  Eductaion details executed");
			// 1 st db opertion//
			sp=con.setSavepoint();
			pstmt1=con.prepareStatement(stdpr);
			// set value for plce holder//
			pstmt1.setInt(1, id);
			pstmt1.setString(2, name);
			pstmt1.setString(3, place);
			pstmt1.executeUpdate();
			System.out.println("STudent personal details executed  !!");
			//2 nd db operation//
			con.commit();
		} catch (ClassNotFoundException | SQLException e) 
		{
			try {
		con.rollback();
		//con.rollback(sp);
		//con.commit();
		System.out.println("operation rolled back");
			}
			catch(SQLException e1) {
				e.printStackTrace();
			}
			e.printStackTrace();
		}
		finally 
		{
			if(pstmt1!=null)
			{
				try {
					pstmt1.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		if(pstmt!=null)
		{
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(con!=null)
		{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("closed costly resources");
		}
	}

}
