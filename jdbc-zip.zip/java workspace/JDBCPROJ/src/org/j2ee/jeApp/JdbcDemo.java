package org.j2ee.jeApp;
public class JdbcDemo {
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Class loaded and registered");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
}
