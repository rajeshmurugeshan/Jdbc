package org.jdbc.PreparedStmtApp;
import java.sql.*;
public class PreparedStmtDemo {
	public static void main(String[] args) {
		Connection con=null;
		PreparedStatement pstmt=null;
		
		String qry="insert into seja4.student values(?,?,?)";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver class loaded and registered");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
			System.out.println("established connection sucessfully");
			pstmt=con.prepareStatement(qry);
			System.out.println("Platform Created  !!");
			// Set Values for place holder//
			pstmt.setInt(1,1);
			pstmt.setString(2,"raam");
			pstmt.setDouble(3,99.99);
			pstmt.executeUpdate();
			
			pstmt.setInt(1,2);
			pstmt.setString(2,"raju");
			pstmt.setDouble(3,89.99);
			pstmt.executeUpdate();
			
			pstmt.setInt(1,3);
			pstmt.setString(2,"xyz");
			pstmt.setDouble(3,79.99);
			pstmt.executeUpdate();
			
			System.out.println("data inserted !!");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			
		}

		finally 
		{
		if(pstmt!=null)
		{
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(con!=null)
		{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("closed costly resources");
		}
		
	}

}
