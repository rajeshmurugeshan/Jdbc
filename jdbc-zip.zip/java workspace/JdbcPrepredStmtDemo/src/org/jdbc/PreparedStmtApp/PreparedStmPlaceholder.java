package org.jdbc.PreparedStmtApp;

import java.sql.*;

public class PreparedStmPlaceholder {
public static void main(String[] args) {
	Connection con=null;
	PreparedStatement pstmt=null;
	
	String qry="insert into seja4.student values(?,?,?)";
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver class loaded");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
		System.out.println("connection established with db server");
		pstmt=con.prepareStatement(qry);
		System.out.println("platform created");
		
		// set values for place holder//
		
		pstmt.setInt(1, 8);
		pstmt.setString(2, "k");
		pstmt.setDouble(3, 88.65);
		pstmt.executeUpdate();
		
		pstmt.setInt(1, 9);
		pstmt.setString(2, "km");
		pstmt.setDouble(3, 88.65);
		pstmt.executeUpdate();
		pstmt.setInt(1, 10);
		pstmt.setString(2, "ik");
		pstmt.setDouble(3, 38.65);
		pstmt.executeUpdate();
		
		System.out.println("data inserted");
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
		if(pstmt!=null)
		{
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	System.out.println("closed costly resources");
}
}
