package org.jdbc.PreparedStmtApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class FetchPerc {
	public static void main(String[] args) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String qry="select * from seja4.student where perc=?";
		Scanner sc=new Scanner(System.in);
		System.out.println("enter perc");
		double perc=sc.nextDouble();
		sc.close();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver class loaded and registered");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
			System.out.println("established connection sucessfully");
			pstmt=con.prepareStatement(qry);
			System.out.println("Platform Created  !!");
			// Set Values for place holder//
			pstmt.setDouble(1,perc);
			
			pstmt.executeQuery();
			if(rs.next())
			{
				int id=rs.getInt(1);
				String  name=rs.getString(2);
				System.out.println(id+" "+name);
			}
			else
				System.out.println("no data fount");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			
		}

		finally 
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		if(pstmt!=null)
		{
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(con!=null)
		{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("closed costly resources");
		}
		
	}
}
